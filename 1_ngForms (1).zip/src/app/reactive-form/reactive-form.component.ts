// Form Builder
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
  regForm: FormGroup;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.regForm = this.formBuilder.group({
      firstname: "",
      lastname: "",
      address: this.formBuilder.group({
        city: "",
        zip: 0,
      })
    });
  }

  reset() {
    this.regForm.reset();
  }

  setValue() {
    this.regForm.setValue({
      firstname: "Abhijeet",
      lastname: "Gole",
      address: {
        city: "Pune",
        zip: 411029,
      }
    })
  }

  patchValue() {
    this.regForm.patchValue({
      firstname: "Abhijeet",
      lastname: "Gole"
    })
  }

  logForm() {
    console.log(this.regForm.value);
  }
}

// 1. FormGroup & FormControl
// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormControl } from '@angular/forms';

// @Component({
//   selector: 'reactive-form',
//   templateUrl: './reactive-form.component.html',
//   styleUrls: ['./reactive-form.component.css']
// })
// export class ReactiveFormComponent implements OnInit {
//   regForm: FormGroup;

//   constructor() { }

//   ngOnInit() {
//     this.regForm = new FormGroup({
//       firstname: new FormControl(),
//       lastname: new FormControl(),
//       address: new FormGroup({
//         city: new FormControl(),
//         zip: new FormControl(),
//       })
//     });
//   }

//   logForm(){
//     console.log(this.regForm.value);
//   }
// }
