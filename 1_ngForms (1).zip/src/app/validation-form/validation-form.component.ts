import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, ValidatorFn } from '@angular/forms';

// function ageRangeValidator(control: AbstractControl): { [key: string]: boolean } | null {
//   if (!control.value) {
//     return null;
//   }

//   if (control.value !== undefined && (isNaN(control.value) || control.value < 18 || control.value > 60)) {
//     return { 'ageRange': true };
//   }

//   return null;
// }

function ageRangeValidator(min: number, max: number): ValidatorFn {
  return function (control: AbstractControl): { [key: string]: boolean } | null {
    if (!control.value) {
      return null;
    }

    if (control.value !== undefined && (isNaN(control.value) || control.value < min || control.value > max)) {
      return { 'ageRange': true };
    }

    return null;
  }

}

@Component({
  selector: 'validation-form',
  templateUrl: './validation-form.component.html',
  styleUrls: ['./validation-form.component.css']
})
export class ValidationFormComponent implements OnInit {

  regForm: FormGroup;

  countries = [
    { 'id': "", 'name': 'Select Country' },
    { 'id': 1, 'name': 'India' },
    { 'id': 2, 'name': 'USA' },
    { 'id': 3, 'name': 'UK' }
  ];

  minAge = 18;
  maxAge = 60;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.regForm = this.formBuilder.group({
      firstname: ["", Validators.required],
      lastname: ["", Validators.compose([
        Validators.required,
        Validators.maxLength(6),
        Validators.minLength(2),
      ])],
      age: ["", [
        Validators.required,
        ageRangeValidator(this.minAge, this.maxAge)
        // ageRangeValidator
      ]],
      address: this.formBuilder.group({
        city: ["", Validators.required],
        country: ["", Validators.required],
        zip: [0, Validators.required],
      })
    });
  }

  get frm() { return this.regForm.controls };
  get address() { return (<FormGroup>this.regForm.controls.address).controls; };

  reset() {
    this.regForm.reset();
  }

  private markFormGroupTouched(formGroup: FormGroup) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }

  logForm() {
    this.markFormGroupTouched(this.regForm);

    if (this.regForm.valid)
      console.log(this.regForm.value);
    else
      console.error("Invalid Form...");
  }

}
