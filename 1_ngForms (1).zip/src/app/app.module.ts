import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { RootComponent } from './root.component';
import { TemplatedFormComponent } from './templated-form/templated-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { ValidationFormComponent } from './validation-form/validation-form.component';

@NgModule({
  declarations: [RootComponent, TemplatedFormComponent, ReactiveFormComponent, ValidationFormComponent],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  providers: [],
  bootstrap: [RootComponent]
})
export class AppModule { }
