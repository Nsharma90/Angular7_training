import { Component, OnInit } from '@angular/core';
import { Observable, Observer, Subject } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css'],
})
export class RootComponent implements OnInit {
  observable: Observable<number>;
  subject: Subject<number>;

  constructor() {

  }

  ngOnInit() {
    // this.observable = Observable.create((ob: Observer<number>) => {
    //   setInterval(() => {
    //     // console.log("next called....");
    //     ob.next(Math.random())
    //   }, 2000);
    // });

    // this.observable.subscribe((data) => {
    //   console.log("S1 - ", data);
    // });

    // this.observable.subscribe((data) => {
    //   console.log("S2 - ", data);
    // });

    this.subject = new Subject<number>();

    setInterval(() => {
      this.subject.next(Math.random())
    }, 2000);

    this.subject.subscribe((data) => {
      console.log("S1 - ", data);
    });

    this.subject.subscribe((data) => {
      console.log("S2 - ", data);
    });

    // this.getPromise().then((data) => {
    //   console.log("Promise - ", data);
    // }, (err) => {
    //   console.error(err);
    // })
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      setInterval(() => resolve(Math.random()), 2000);
    });
  }
}
