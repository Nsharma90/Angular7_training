import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { RootComponent } from './root.component';
import { AsyncPromiseComponent } from './async-promise.component';
import { AsyncObservableComponent } from './async-observable.component';

@NgModule({
  declarations: [RootComponent, AsyncPromiseComponent, AsyncObservableComponent],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  providers: [],
  bootstrap: [RootComponent]
})
export class AppModule { }
