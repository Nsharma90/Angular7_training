module.exports = function (env = "dev") {
    // console.log(env);
    return require(`./config/webpack.${env}.js`)(env);
}