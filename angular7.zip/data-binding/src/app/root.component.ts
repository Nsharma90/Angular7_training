import { Component, OnInit, ViewEncapsulation, AfterViewInit, NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css'],
  // encapsulation: ViewEncapsulation.None
})
export class RootComponent implements OnInit, AfterViewInit {
  private message: string;
  private flag: boolean;

  constructor(private ngZone: NgZone) {
    this.message = "Hello World!";
    this.flag = false;
  }

  ngOnInit() {
  }

  doChange() {
    this.message = new Date().toLocaleTimeString();
  }

  ngAfterViewInit() {
    // document.getElementById("btnJS").addEventListener("click", () => {
    //   this.message = new Date().toLocaleTimeString();
    // })

    this.ngZone.runOutsideAngular(() => {
      document.getElementById("btnJS").addEventListener("click", () => {
        this.message = new Date().toLocaleTimeString();
        console.log(this.message);
      })
    });
  }
}
