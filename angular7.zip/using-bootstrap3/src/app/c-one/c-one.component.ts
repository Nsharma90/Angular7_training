// Element Inline Style
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-c-one',
//   template: `
//       <h2 class="text-success"> Hello from Component One </h2>
//       <h2 class="text-success" style="border-style: solid; border-width: 2px; border-color: green"> Hello from Component One </h2>
//   `
// })
// export class COneComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

// // Template Inline Style
// import { Component, OnInit, ViewEncapsulation } from '@angular/core';

// @Component({
//   selector: 'app-c-one',
//   template: `
//       <style>
//         .card {
//           border-style: solid; 
//           border-width: 2px; 
//           border-color: green
//         }
//       </style>
//       <h2 class="text-success"> Hello from Component One </h2>
//       <h2 class="card"> Hello from Component One </h2>
//   `,
//   encapsulation: ViewEncapsulation.ShadowDom
// })
// export class COneComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

// Component Inline Style
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-c-one',
//   styles: [`
//     .card {
//       border-style: solid; 
//       border-width: 2px; 
//       border-color: green
//     }
//   `],
//   template: `
//       <h2 class="text-success"> Hello from Component One </h2>
//       <h2 class="card"> Hello from Component One </h2>
//   `
// })
// export class COneComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

// External CSS
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-one',
  templateUrl: './c-one.component.html',
  styleUrls: ['./c-one.component.css']
})
export class COneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
