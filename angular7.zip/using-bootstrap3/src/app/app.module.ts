import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { COneComponent } from './c-one/c-one.component';
import { CTwoComponent } from './c-two/c-two.component';
import { RootComponent } from './root.component';

@NgModule({
  declarations: [
  COneComponent,
  CTwoComponent,
  RootComponent],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [
    RootComponent
  ]
})
export class AppModule { }
