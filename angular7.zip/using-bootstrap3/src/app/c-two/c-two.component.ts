// Element Inline Style
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-c-two',
//   template: `
//       <h2 class="text-info"> Hello from Component Two </h2>
//       <h2 class="text-info" style="border-style: dashed; border-width: 2px; border-color: blue"> Hello from Component One </h2>
//   `
// })
// export class CTwoComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

// Template inline style
// import { Component, OnInit, ViewEncapsulation } from '@angular/core';

// @Component({
//   selector: 'app-c-two',
//   template: `
//     <style>
//       .card {
//         border-style: dashed; 
//         border-width: 2px; 
//         border-color: blue
//       }
//     </style>
//       <h2 class="text-info"> Hello from Component Two </h2>
//       <h2 class="card"> Hello from Component One </h2>
//   `,
//   encapsulation: ViewEncapsulation.ShadowDom
// })
// export class CTwoComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

// Component inline style
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-c-two',
//   styles: [
//     `
    // .card {
    //   border-style: dashed; 
    //   border-width: 2px; 
    //   border-color: blue
//     `
//   ],
//   template: `
//       <h2 class="text-info"> Hello from Component Two </h2>
//       <h2 class="card"> Hello from Component One </h2>
//   `
// })
// export class CTwoComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

// External CSS
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-two',
  templateUrl: './c-two.component.html',
  styleUrls: ['./c-two.component.css']
})
export class CTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
