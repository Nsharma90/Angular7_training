import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css'],
  // encapsulation: ViewEncapsulation.None
})
export class RootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
