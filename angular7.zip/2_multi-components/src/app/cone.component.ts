import { Component } from "@angular/core";

@Component({
    selector: 'c-one',
    template: `
        <h1>Hello from Component One!</h1>
    `
})
export class COneComponent { }